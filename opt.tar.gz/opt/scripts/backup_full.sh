#!/bin/bash

# script de backup - comprime un directorio en tar.gz
# uso: backup_full.sh -origen <dir> -destino <dir>
#      backup_full.sh <dir_origen> <dir_destino>

ORIGEN=""
DESTINO=""

# si no pasan argumentos o piden ayuda, muestro como usarlo
if [[ $# -eq 0 || "$1" == "-help" || "$1" == "--help" || "$1" == "-h" ]]; then
    echo "Uso: backup_full.sh -origen <dir_origen> -destino <dir_destino>"
    echo "     backup_full.sh <dir_origen> <dir_destino>"
    echo ""
    echo "  -origen   directorio a respaldar"
    echo "  -destino  donde guardar el backup"
    echo "  -help     muestra esta ayuda"
    echo ""
    echo "Se puede pasar con flags o de forma posicional (origen primero, destino despues)."
    echo "El archivo se guarda como: <nombre>_bkp_YYYYMMDD.tar.gz"
    echo "Ejemplo: backup_full.sh -origen /var/log -destino /backup_dir"
    echo "         backup_full.sh /var/log /backup_dir"
    exit 0
fi

# parseo los argumentos: acepto flags (-origen/-destino) o posicional (origen destino)
while [[ $# -gt 0 ]]; do
    case "$1" in
        -origen)
            ORIGEN="$2"
            shift 2
            ;;
        -destino)
            DESTINO="$2"
            shift 2
            ;;
        -*)
            echo "ERROR: opcion desconocida: $1"
            echo "Usa -help para ver el uso."
            exit 1
            ;;
        *)
            # argumento sin flag: el primero es origen, el segundo destino
            if [[ -z "$ORIGEN" ]]; then
                ORIGEN="$1"
            elif [[ -z "$DESTINO" ]]; then
                DESTINO="$1"
            else
                echo "ERROR: demasiados argumentos"
                echo "Usa -help para ver el uso."
                exit 1
            fi
            shift
            ;;
    esac
done

# valida que se hayan pasado los dos argumentos
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
    echo "ERROR: falta -origen o -destino"
    echo "Usa -help para ver el uso."
    exit 1
fi

# valida que el origen exista
if [[ ! -d "$ORIGEN" ]]; then
    echo "ERROR: el origen '$ORIGEN' no existe"
    exit 1
fi

# valida que el destino exista y se pueda escribir
if [[ ! -d "$DESTINO" ]]; then
    echo "ERROR: el destino '$DESTINO' no existe o no esta montado"
    exit 1
fi

if [[ ! -w "$DESTINO" ]]; then
    echo "ERROR: no tengo permiso de escritura en '$DESTINO'"
    exit 1
fi

# armo el nombre del archivo con fecha
FECHA=$(date +%Y%m%d)
BASENAME=$(basename "$ORIGEN")
ARCHIVO="${BASENAME}_bkp_${FECHA}.tar.gz"
DESTINO_FINAL="${DESTINO}/${ARCHIVO}"

echo "Iniciando backup: $ORIGEN -> $DESTINO_FINAL"

tar -czf "$DESTINO_FINAL" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")" 2>&1

if [[ $? -le 1 ]]; then
    TAMANO=$(du -sh "$DESTINO_FINAL" | cut -f1)
    echo "Backup terminado: $ARCHIVO ($TAMANO)"
    exit 0
else
    echo "ERROR: fallo el backup"
    exit 1
fi
