#!/bin/bash

# script de limpieza - borra backups tar.gz con mas de X dias
# uso: cleanup_backups.sh [directorio] [dias]
#      por defecto: /backup_dir y 20 dias

DIR="/backup_dir"
DIAS=20

# si piden ayuda, muestro como usarlo
if [[ "$1" == "-help" || "$1" == "--help" || "$1" == "-h" ]]; then
    echo "Uso: cleanup_backups.sh [directorio] [dias]"
    echo ""
    echo "  directorio  donde estan los backups (por defecto /backup_dir)"
    echo "  dias        retencion en dias (por defecto 20)"
    echo "  -help       muestra esta ayuda"
    echo ""
    echo "Borra los archivos *.tar.gz con mas de <dias> dias de antiguedad."
    echo "Ejemplo: cleanup_backups.sh"
    echo "         cleanup_backups.sh /backup_dir"
    echo "         cleanup_backups.sh /backup_dir 30"
    exit 0
fi

# si pasan argumentos, piso los valores por defecto
if [[ -n "$1" ]]; then
    DIR="$1"
fi
if [[ -n "$2" ]]; then
    DIAS="$2"
fi

# valida que los dias sean un numero
if ! [[ "$DIAS" =~ ^[0-9]+$ ]]; then
    echo "ERROR: los dias deben ser un numero: $DIAS"
    exit 1
fi

# valida que exista el directorio
if [[ ! -d "$DIR" ]]; then
    echo "ERROR: el directorio '$DIR' no existe"
    exit 1
fi

echo "Limpieza de backups en $DIR (retencion: $DIAS dias)"

# busca los tar.gz con mas de X dias (sin entrar en subdirectorios)
VIEJOS=$(find "$DIR" -maxdepth 1 -name "*.tar.gz" -type f -mtime +"$DIAS")

# si no hay nada para borrar, aviso y salgo
if [[ -z "$VIEJOS" ]]; then
    echo "No hay backups viejos para borrar"
    exit 0
fi

# muestro lo que voy a borrar (nombre + fecha de modificacion)
echo "Backups con mas de $DIAS dias:"
for f in $VIEJOS; do
    echo "  $(basename "$f") (modificado: $(date -r "$f" '+%Y-%m-%d'))"
done

# borro uno por uno y dejo registro
BORRADOS=0
for f in $VIEJOS; do
    echo "Borrando: $(basename "$f")"
    rm -f "$f"
    BORRADOS=$((BORRADOS+1))
done

echo "Limpieza terminada: $BORRADOS archivos borrados"
exit 0
